/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function setVariable(nombre, valor)
{
    localStorage[nombre] = valor;
}
function getIdCiudad()
{
    var idCiudad;
    if (localStorage['idCiudad'] != null)
        idCiudad = localStorage['idCiudad'];
    else
        idCiudad = 151;
    return idCiudad;
}
function getIdUsuario()
{
    var idUsuario;
    if (localStorage['idUsuario'] != null)
        idCiudad = localStorage['idUsuario'];
    else
        idCiudad = -1;
    return idCiudad;
}
function getIdDireccion()
{
    var id;
    if (localStorage['idDireccion'] != null)
        id = localStorage['idDireccion'];
    else
        id = -1;
    return id;
}
function getCx()
{
    var r;
    if (localStorage['cx'] != null)
        r = localStorage['cx'];
    else
        r = 0
    return r;
}
function getCy()
{
    var r;
    if (localStorage['cy'] != null)
        r = localStorage['cy'];
    else
        r = 0;
    return r;
}
function getCarrito()
{
    var r;
    if (localStorage['carrito'] != null)
    {
        console.log("Ya existe un carrito");
        var aux = localStorage['carrito'];
        r = setCarrito(aux);
    } else
        r = new Carrito(getIdUsuario());
    return r;
}
function getCorreoUsuario()
{
    var r;
    if (localStorage['correoUsuario'] != null)
        r = localStorage['correoUsuario'];
    else
        r = null;
    return r;
}
function checkConnection()
{
    var networkState = navigator.network.connection.type;
    var states = {};
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI] = 'WiFi connection';
    states[Connection.CELL_2G] = 'Cell 2G connection';
    states[Connection.CELL_3G] = 'Cell 3G connection';
    states[Connection.CELL_4G] = 'Cell 4G connection';
    states[Connection.CELL] = 'Cell generic connection';
    states[Connection.NONE] = 'No network connection';
    if (states[networkState] == 'Unknown connection' || states[networkState] == 'No network connection')
    {
        return false;
    }
    return true;


}
function dialogo(titulo, mensaje)
{
    $("#txtTitulo").html(titulo);
    $("#txtMensaje").html(mensaje);
    $("#dialog").dialog("open");
}
function Carrito(id)
{
    //Atributos
    //Id del usuario de este carrito de compras
    this.idUsuario = id;
    //Vector con los productos del carrito de compras
    this.productos = new Array();
    //Vector que contiene las adiciones del carrito de compras
    this.adiciones = new Array();
    //Variables para tener un id para cada producto, y un id para cada adicion
    this.cantP = 0;
    this.cantA = 0;
    //Variable para saber el total del carrito de compras
    this.total = 0;
    //Funciones
    this.addProducto = function(idProducto, precio, cantidad, nombre)
    {
        console.log("Agrege un producto");
        var producto = new Array(5);
        producto[0] = this.cantP;
        producto[1] = idProducto;
        producto[2] = precio;
        producto[3] = cantidad;
        producto[4] = nombre;
        this.productos[this.productos.length] = producto;
        this.cantP++;
        return (this.cantP-1);
    };
    this.addProducto1 = function(id, idProducto, precio, cantidad, nombre, pos)
    {
        var producto = new Array(5);
        producto[0] = id;
        producto[1] = idProducto;
        producto[2] = precio;
        producto[3] = cantidad;
        producto[4] = nombre;
        this.productos[pos] = producto;
        this.cantP++;
    };
    this.addAdicion = function(idAdicion, idProducto, precio, nombre)
    {
        console.log("Agrege una adicion");
        var adicion = new Array(5);
        adicion[0] = this.cantA;
        adicion[1] = idAdicion;
        adicion[2] = idProducto;
        adicion[3] = precio;
        adicion[4] = nombre;
        this.adiciones[this.adiciones.length] = adicion;
        this.cantA++;
    };
    this.addAdicion1 = function(id, idAdicion, idProducto, precio, nombre, pos)
    {
        var adicion = new Array(5);
        adicion[0] = id;
        adicion[1] = idAdicion;
        adicion[2] = idProducto;
        adicion[3] = precio;
        adicion[4] = nombre;
        this.adiciones[pos] = adicion;
    };
    this.calcularTotal = function()
    {
        //Recorro cada producto
        for (i = 0; i < this.productos.length; i++)
        {
            //Obtengo el producto de esta fila
            var producto = this.productos[i];
            //Multiplico el precio del producto por la cantidad
            var semi = producto[2] * producto[3];
            this.total += semi;
        }
        //Recorro cada adicion
        for (i = 0; i < this.adiciones.length; i++)
        {
            //Obtengo la adicion de esta fila
            var producto = this.adiciones[i];
            //Multiplico el precio del producto por la cantidad
            var semi = producto[2] * producto[3];
            this.total += semi;
        }
    };
    //Elimina un producto del carrito de compras
    this.eliminarProducto = function(id)
    {
        for (i = 0; i < this.productos.length; i++)
        {
            var producto = this.productos[i];
            if (producto[0] == id)
            {
                this.productos.splice(i, 1);
            }
        }
    };

    //Genero un string de este objeto
    this.toString = function()
    {
        var str = "";
        str += this.idUsuario + "?";
        str += this.cantP + "?";
        str += this.cantA + "?";
        //Recorro los productos
        if (this.productos.length > 0)
        {
            for (i = 0; i < this.productos.length; i++)
            {
                //Obtengo el producto de esta fila
                var producto = this.productos[i];
                str += producto[0] + "-" + producto[1] + "-" + producto[2] + "-" + producto[3] + "-" + producto[4] + "*";
            }
        } else {
            str += "null";
        }

        str += "?";
        //Recorro cada adicion
        if (this.adiciones.length > 0)
        {
            for (i = 0; i < this.adiciones.length; i++)
            {
                //Obtengo el adicion de esta fila
                var adiciones = this.adiciones[i];
                str += adiciones[0] + "-" + adiciones[1] + "-" + adiciones[2] + "-" + adiciones[3] + "-" + adiciones[4] + "*";
            }
        } else {
            str += "null";
        }
        return str;

    };

}
//Se encarga de convertir una cadena de texto en un objeto carrito
function setCarrito(str)
{
    console.log("str: "+str);
    //Variables globales
    var idUsuario, cantP, cantA;
    //Variables del producto
    var productos, id, idp, cantidad, precio, nombre;
    //variables adiciones
    var adiciones, idA;

    //Recorro el string
    var ele = str.split("?");
    idUsuario = ele[0];
    cantP = ele[1];
    cantA = ele[2];
    productos = ele[3];
    adiciones = ele[4];
    //creo el objeto
    var car = new Carrito(idUsuario);
    car.cantP = cantP;
    car.cantA = cantA;
    //ahora recorro cada producto
    if (productos != "null")
    {
        var pro = productos.split("*");
        for (var i = 0; i < pro.length - 1; i++)
        {
            //Obtengo los elementos de cada producto
            var pro2 = pro[i].split("-");
            id = pro2[0];
            idp = pro2[1];
            precio = pro2[2];
            cantidad = pro2[3];
            nombre = pro2[4];
            //Agrego el producto al carrito
            car.addProducto1(id, idp, precio, cantidad, nombre, i);
        }
    }
    //ahora recorro cada adicion
    if (adiciones != "null")
    {
        var adi = adiciones.split("*");
        for (var i = 0; i < adi.length - 1; i++)
        {
            //Obtengo los elementos de cada producto
            var adi2 = adi[i].split("-");
            id = adi2[0];
            idA = adi2[1];
            idp = adi2[2];
            precio = adi2[3];
            nombre = adi2[4];
            //Agrego la adicion al carrito
            car.addAdicion1(id, idA, idp, precio, nombre, i);
        }
    }
    return car;

}
function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
function addProducto(id, precio, cantidad, nombre)
{
    var car = getCarrito();
    var r=car.addProducto(id, precio, cantidad, nombre);
    setVariable("carrito", car.toString());
    return r;
}
function addAdicion(idA, idP, precio, nombre)
{
    var car = getCarrito();
    car.addAdicion(idA, idP, precio, nombre);
    setVariable("carrito", car.toString());
}
